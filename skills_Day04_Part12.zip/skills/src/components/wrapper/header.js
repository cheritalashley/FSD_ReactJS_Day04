import React from "react";
import { Link } from 'react-router-dom';
import logo from '../../chart.gif';

function Header(){
  return (
    <header>
      <img src={logo} id="logo" alt="Logo" />
      <h1><a href="index.html">Skillsoft Weight Tracker</a></h1>
      <nav>
        <ul>
          <li><Link to="/home">home</Link></li>
          <li><Link to="/enterweight">enter weight</Link></li>
          <li><Link to="/myweight">my weight</Link></li>
          <li><Link to="/teamweights">team weights</Link></li>
          <li><Link to="/login">login</Link></li>
        </ul>
      </nav>
    </header>
  )
}

export default Header
