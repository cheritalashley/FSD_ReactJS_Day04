import React from "react";
import AddemployeeContainer from "./addemployeecontainer";
import Footer from "./../wrapper/footer";
import Header from "./../wrapper/header";

function Addemployee(){
  return (
    <div>
      <Header />
      <AddemployeeContainer />
      <Footer />
    </div>
  )
}

export default Addemployee
