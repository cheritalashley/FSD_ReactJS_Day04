import React from "react";
import AddemployeeMain from "./addemployeemain";
import Aside from "./../wrapper/aside";
//
function AddemployeeContainer(){
  return (
    <div id="container">
      <AddemployeeMain />
      <Aside />
    </div>
  )
}
//
export default AddemployeeContainer;
