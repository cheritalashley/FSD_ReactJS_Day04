import React from "react";
import EwContainer from "./ewcontainer";
import Footer from "./../wrapper/footer";
import Header from "./../wrapper/header";

function EnterWeight(){
  return (
    <div>
      <Header />
      <EwContainer />
      <Footer />
    </div>
  )
}

export default EnterWeight
