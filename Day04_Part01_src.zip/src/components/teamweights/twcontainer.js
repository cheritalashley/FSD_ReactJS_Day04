import React from "react";
import TwMain from "./twmain";
import Aside from "./../wrapper/aside";
//
function TwContainer(){
  return (
    <div id="container">
      <TwMain />
      <Aside />
    </div>
  )
}
//
export default TwContainer
