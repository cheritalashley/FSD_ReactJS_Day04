import React from 'react';
import './styles.css';
import {BrowserRouter, Route} from 'react-router-dom';
import Home from './components/home/home';
import Teamweights from './components/teamweights/teamweights';
import Login from './components/login/login';
import EnterWeight from './components/enterweight/enterweight';

function App() {
  return (
    <div>
      <BrowserRouter>
        <Route exact path="/" component={Home}/>
        <Route path="/home" component={Home}/>
        <Route path="/enterweight" component={EnterWeight}/>
        <Route path="/teamweights" component={Teamweights}/>
        <Route path="/login" component={Login}/>
      </BrowserRouter>
    </div>
  );
}

export default App;
