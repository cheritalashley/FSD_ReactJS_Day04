import React from "react";
import TwContainer from "./twcontainer";
import Footer from "./../wrapper/footer";
import Header from "./../wrapper/header";

function Teamweights(){
  return (
    <div>
      <Header />
      <TwContainer />
      <Footer />
    </div>
  )
}

export default Teamweights
