import React from "react";
import EwMain from "./ewmain";
import Aside from "./../wrapper/aside";
//
function EwContainer(){
  return (
    <div id="container">
      <EwMain />
      <Aside />
    </div>
  )
}
//
export default EwContainer
