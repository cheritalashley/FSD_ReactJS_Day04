import React from "react";
import MwContainer from "./myweightscontainer";
import Footer from "./../wrapper/footer";
import Header from "./../wrapper/header";

function MyWeights(){
  return (
    <div>
      <Header />
      <MwContainer />
      <Footer />
    </div>
  )
}

export default MyWeights
