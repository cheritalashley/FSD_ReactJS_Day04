import React from "react";
import MwMain from "./myweightsmain";
import Aside from "./../wrapper/aside";
//
function MwContainer(){
  return (
    <div>
      <MwMain />
      <Aside />
    </div>
  )
}
//
export default MwContainer
