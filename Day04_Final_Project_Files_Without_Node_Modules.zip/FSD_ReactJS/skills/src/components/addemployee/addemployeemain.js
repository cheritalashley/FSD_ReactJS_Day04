import React, {Component} from "react";

class AddemployeeMain extends Component{
  constructor(props) {
    super(props);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleFieldChange = this.handleFieldChange.bind(this);
    this.state = {
      empName:"",
      empWeight:"",
      postStatus:"",
      token:""
    }
  }

  render() {
    return (
      <main>
        <h2>Add new employee</h2>
        <form onSubmit={this.handleSubmit}>
          <div>
            <label>
              Name:
                <input type="text" name="empName" onChange={this.handleFieldChange} />
            </label>
          </div>
          <div>
            <label>
              Password:
                <input type="text" name="empPass" onChange={this.handleFieldChange} />
            </label>
          </div>
          <div>
            <input type="submit" value="Submit" />
          </div>
          <div>
            <span>{this.state.postStatus}</span>
          </div>
        </form>
      </main>
    )
  }

  handleSubmit(event) {
    const self = this;
    event.preventDefault();
    fetch('http://localhost:8000/addnewemployee', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        empName: this.state.empName,
        empPass: this.state.empPass
      })
    }).then(function(res){
        return res.json();
    }).then(function(data){
        self.setState({postStatus: data.message});
        self.setState({token: data.token});
        localStorage.setItem('token', self.state.token)
    }).catch(function(err){
        console.log(err);
    })
  }

  handleFieldChange(event) {
    this.setState({
      [event.target.name]:event.target.value
    })
  }


}



export default AddemployeeMain;
