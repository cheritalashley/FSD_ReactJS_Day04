import React from "react";

function Footer(){
  return (
    <footer>
      <hr />
      Copyright &copy; 2020. All rights reserved
    </footer>
  )
}

export default Footer
