const controller = require('./../controllers/controller');
const auth = require('../controllers/auth');
//
module.exports = function(api){
  api.route('/').get(controller.getdefault);
  api.route('/getemployees').get(auth, controller.getemployees);
  api.route('/addnewemployee').post(controller.addnewemployee);
  api.route('/addnewweight').put(controller.addnewweight);
  api.route('/loginuser').post(controller.loginuser);
  api.route('/getbyname/:employeeName').get(controller.getbyname);
};
