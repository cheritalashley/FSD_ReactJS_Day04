const Employee = require('../models/employee');
const vschema = require('./validate');
const jwt = require('jsonwebtoken');
//
exports.loginuser = function(req, res){
	let empName = req.body.empName;
	let empPass = req.body.empPass;
  Employee.find({empName:empName}, function(err, results) {
    if (err) res.end(err);
    if (empPass == results[0].empPass){
      jwt.sign({
        empName:results[0].empName,
        userID:results[0]._id
      },
        "mysecret",
        {expiresIn : "1h"},
        function(err, token){
          if(err) throw err;
          res.json({token:token});
        }
      )
    } else {
      res.send({status:"Login Failed"});
    }
  });
};
//
exports.getdefault = function(req, res){
  res.send('You are on the root route.');
};
exports.getemployees = function(req, res){
  Employee.find({}, function(err, results){
    if (err)
      res.end(err);
    res.json(results);
  });
};
exports.addnewemployee = function(req, res){
  const {error} = vschema.validate(req.body);
  const Emp = new Employee();
  if(error)
    return res.status(400).json({error:error.details[0].message});
  Emp.empName = req.body.empName;
  Emp.empPass = req.body.empPass;
  Emp.save({}, function(err){
    if (err)
     res.end(err);
		 jwt.sign({
			 empName:Emp.empName
		 },
			 "mysecret",
			 {expiresIn : "1h"},
			 function(err, token){
				 if(err) throw err;
				 res.json({token:token, message:`Created ${Emp.empName}`});
			 }
		 );
  });
};
//
exports.addnewweight = function(req, res){
  let empName = req.body.empName;
  let empWeight = req.body. empWeight;
  Employee.updateOne(
    {empName: empName},
    {$addToSet:
      { employeeWeights :
        {
          empWeight:empWeight
        }
      }
    },
    {upsert : true },
    function(err, doc) {
      if(err) {
        return console.log(err);
      } else {
        return res.send("done");
      }
    }
  );
};
